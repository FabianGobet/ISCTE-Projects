import React, { Component, Fragment } from "react";
import Home from "./components/Home";
class App extends Component { 
 render() {
 return (
 <Fragment>
 <Home />
 </Fragment>
 );
 }
}
export default App;