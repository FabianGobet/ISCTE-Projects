export const API_URL_PRODUTO = "http://localhost:8000/store/api/produtos/";
export const API_URL_PRODUTO_IMAGEM = "http://localhost:8000/store/api/produtoimagem/";